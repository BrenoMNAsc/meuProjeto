#include <stdio.h>
#include <locale.h>
int main(){
	setlocale(LC_ALL, "Portuguese");
	/*Fa�a um algoritmo que receba um inteiro n e imprima os n primeiros termos da sequ�ncia
de Fibonacci. A s�rie � dada pelos termos: 1, 1, 2, 3, 5, 8, 13...*/
	int a = 1, b = 1, atual, i, n;
	//coloquei esse = 1 pq se n, n dava o valor dos 3 primeiros
	printf("Digite o valor de n: \n");
	scanf("%d", &n);
	for(i=1; i<=n; i++){
		if(i==1){
			printf("1 ");
		}
		else if(i==2){
			printf("1 ");
		}
		else {
			atual = a+b;
			printf("%d ", atual);
			a=b;
			b=atual;
		}
	}
	printf("\n");
	return 0;
}
